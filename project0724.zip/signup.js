document.getElementById("signupForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const username = document.getElementById("username");
    const password = document.getElementById("password");
    const confirmPassword = document.getElementById("confirmPassword");
    const message = document.getElementById("message");

    if (password.value === confirmPassword.value) {
        message.textContent = "회원가입이 완료되었습니다";
        message.className = "success";

        
        username.value = "";
        password.value = "";
        confirmPassword.value = "";
    } else {
        message.textContent = "패스워드가 일치하지 않습니다";
        message.className = "error";
    }
});

document.addEventListener("DOMContentLoaded", function () {
    let currentIndex = 1;
    const slideImage = document.getElementById("slideImage");

    setInterval(() => {
        currentIndex++;
        if (currentIndex > 3) currentIndex = 1;
        slideImage.src = `img/${currentIndex}.jpg`;
    }, 3000);
});
