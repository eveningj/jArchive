const data = {
  "여자상의": [
    { name: "로고 실키 유넥 티셔츠 - 화이트", price: "₩19,000", img: 1 },
    { name: "(공용) 반팔 페인팅 티셔츠", price: "₩29,000", img: 2 },
    { name: "(공용) 반팔 체크셔츠", price: "₩39,000", img: 3 },
    { name: "LACE PUNCHING 90s SHORT SLEEVE TEE_RED", price: "₩65,000", img: 4 },
    { name: "스피릿추얼 프룻 그로운 반팔 티셔츠", price: "₩59,000", img: 5 },
    { name: "CLASSIC LOGO RINGER TEE navy", price: "₩45,000", img: 7 },
    { name: "Basic Logo Tee Grey", price: "₩35,800", img: 8 }
  ],
  "여자하의": [
    { name: "Everyday woven banding short", price: "₩39,000", img: 1 },
    { name: "투턱 나일론 슬랙스", price: "₩45,000", img: 2 },
    { name: "컷오프 포인트 데님 팬츠", price: "₩22,000", img: 3 },
    { name: "Brown Jogger Pants", price: "₩35,000", img: 4 },
    { name: "Shot Pants", price: "₩40,000", img: 5 },
    { name: "Timber Pants 'black'", price: "₩78,000", img: 6 },
    { name: "단델리온 워싱 데님 팬츠", price: "₩98,000", img: 7 },
    { name: "Comfort string pants", price: "₩54,000", img: 8 }
  ]
};

function makeCard(cat, item) {
  const list = document.querySelector(".list");

  const card = document.createElement("div");
  card.className = "product-card";

  const imgBox = document.createElement("div");
  imgBox.className = "img-box";

  const imgTag = document.createElement("img");
  imgTag.src = cat + "/" + item.img + ".jpg";
  imgTag.alt = item.name + " 사진";
  imgTag.style.width = "100%";
  imgTag.style.height = "100%";
  imgTag.style.objectFit = "cover";

  imgBox.appendChild(imgTag);

  const n = document.createElement("div");
  n.className = "name";
  n.textContent = item.name;

  const p = document.createElement("div");
  p.className = "price";
  p.textContent = item.price;

  card.appendChild(imgBox);
  card.appendChild(n);
  card.appendChild(p);

  list.appendChild(card);
}

function showMenu(name) {
  const title = document.getElementById("titleArea");
  title.textContent = '"' + name + '" 목록 보는중';

  const list = document.querySelector(".list");
  list.innerHTML = "";

  const menuItems = document.querySelectorAll(".girllist li");
  menuItems.forEach(li => {
    if(li.textContent === name) {
      li.classList.add("active");
    } else {
      li.classList.remove("active");
    }
  });

  if(name === "ALL") {
    ["여자상의", "여자하의"].forEach(cat => {
      data[cat].forEach(item => {
        makeCard(cat, item);
      });
    });
  } else if(data[name]) {
    data[name].forEach(item => {
      makeCard(name, item);
    });
  }

  window.scrollTo({top:0, behavior:"smooth"});
}

document.addEventListener("DOMContentLoaded", function() {
  showMenu("ALL");
});

