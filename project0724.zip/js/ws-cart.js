const products = document.querySelectorAll(".product");

const totalPriceEl = document.querySelector("#total-price");
const finalPriceEl = document.querySelector("#final-price");

products.forEach(function(product) {
  const minusBtn = product.querySelector(".minus");
  const plusBtn = product.querySelector(".plus");
  const countSpan = product.querySelector(".count");
  const unitPrice = +product.getAttribute("data-price"); 

  plusBtn.addEventListener("click", function() {
    let count = +countSpan.innerText; 
    count += 1;
    countSpan.innerText = count;
    updateTotal();
  });

  minusBtn.addEventListener("click", function() {
    let count = +countSpan.innerText;
    if (count > 1) {
      count -= 1;
      countSpan.innerText = count;
      updateTotal();
    }
  });
});

function updateTotal() {
  let total = 0;

  products.forEach(function(product) {
    const count = +product.querySelector(".count").innerText;
    const price = +product.getAttribute("data-price");
    total += count * price;
  });

  totalPriceEl.innerText = total.toLocaleString();
  finalPriceEl.innerText = total.toLocaleString();
}

updateTotal();
