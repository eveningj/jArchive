const naver = document.querySelector(".naver-login");
naver.addEventListener("click",function(){
    window.location.href = "https://nid.naver.com/nidlogin.login?mode=form&url=https://www.naver.com/";
});

const kakao = document.querySelector(".kakao-login");
kakao.addEventListener("click",function(){
    window.location.href = "https://accounts.kakao.com/login/?continue=https%3A%2F%2Fcs.kakao.com%2Fhelps%3Fcategory%3D25#login";
});

const apple = document.querySelector(".apple-login");
apple.addEventListener("click",function(){
    window.location.href = "https://account.apple.com/sign-in";
});

const facebook = document.querySelector(".facebook-login");
facebook.addEventListener("click",function(){
    window.location.href = "https://www.facebook.com/";
});

const email = document.querySelector(".email-login");
email.addEventListener("click",function(){
    window.location.href = "https://accounts.google.com/v3/signin/identifier?ifkv=AdBytiMj-UMHVlkKtW9gRW0dEi5iuwEU45ycaECo16DUBgAaJCKkCdzn4s-piEP_g9F0fil5OTCtmg&service=mail&flowName=GlifWebSignIn&flowEntry=ServiceLogin&dsh=S2114501444%3A1753259187274171";
});