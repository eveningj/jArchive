const data = {
  "남자상의": [
    { name: "(공용) 반팔 티셔츠", price: "₩19,000", img: 1 },
    { name: "(공용) 반팔 페인팅 티셔츠", price: "₩29,400", img: 2 },
    { name: "Wrinkle Check Boxy Overfit Roll up Half Shirt Dark Navy", price: "₩39,000", img: 3 },
    { name: "T-Logo Tee Heather Grey", price: "₩38,500", img: 4 },
    { name: "Tompkins Loopwheeled Tubular Tee", price: "₩59,000", img: 5 },
    { name: "CLASSIC LOGO RINGER TEE navy", price: "₩45,000", img: 7 },
    { name: "CLASSIC LOGO TEE", price: "₩25,300", img: 8 }
  ],
  "남자하의": [
    { name: "G 쇼츠 Chino", price: "₩84,300", img: 1 },
    { name: "나일론 원턱 팬츠_청록", price: "₩53,200", img: 2 },
    { name: "DD structure balloon sweat pants (BLACK)", price: "₩87,000", img: 3 },
    { name: "믹스 스트라이프 밴딩 팬츠", price: "₩35,000", img: 4 },
    { name: "씬테크 우븐 세미 와이드 스트링 팬츠 Black", price: "₩40,000", img: 5 },
    { name: "루즈핏 워크쇼츠 Black", price: "₩52,500", img: 6 },
    { name: "OVERFIT STITCH DENIM PANTS LIGHT BLACK", price: "₩56,000", img: 7 },
    { name: "플루크 버뮤다 데님 하프팬츠", price: "₩54,800", img: 8 }
  ]
};

function makeCard(cat, item) {
  const list = document.querySelector(".list");

  const card = document.createElement("div");
  card.className = "product-card";

  const imgBox = document.createElement("div");
  imgBox.className = "img-box";

  const imgTag = document.createElement("img");
  imgTag.src = cat + "/" + item.img + ".jpg";
  imgTag.alt = item.name + " 사진";
  imgTag.style.width = "100%";
  imgTag.style.height = "100%";
  imgTag.style.objectFit = "cover";

  imgBox.appendChild(imgTag);

  const n = document.createElement("div");
  n.className = "name";
  n.textContent = item.name;

  const p = document.createElement("div");
  p.className = "price";
  p.textContent = item.price;

  card.appendChild(imgBox);
  card.appendChild(n);
  card.appendChild(p);

  list.appendChild(card);
}

function showMenu(name) {
  const title = document.getElementById("titleArea");
  title.textContent = '"' + name + '" 목록 보는중';

  const list = document.querySelector(".list");
  list.innerHTML = "";

  const menuItems = document.querySelectorAll(".manlist li");
  menuItems.forEach(li => {
    if(li.textContent === name) {
      li.classList.add("active");
    } else {
      li.classList.remove("active");
    }
  });

  if(name === "ALL") {
    ["남자상의", "남자하의"].forEach(cat => {
      data[cat].forEach(item => {
        makeCard(cat, item);
      });
    });
  } else if(data[name]) {
    data[name].forEach(item => {
      makeCard(name, item);
    });
  }

  window.scrollTo({top:0, behavior:"smooth"});
}

document.addEventListener("DOMContentLoaded", function() {
  showMenu("ALL");
});
